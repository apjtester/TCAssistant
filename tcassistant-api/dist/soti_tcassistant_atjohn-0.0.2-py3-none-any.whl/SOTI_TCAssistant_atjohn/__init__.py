from flask import Flask

def create_app():
    app = Flask(__name__)

    # Import and register routes
    from .apidocs.chat import Chat
    from .apidocs.update_data import Revise
    from .apidocs.welcome import Items,Welcome
    
    Chat(app)
    Revise(app)
    Items(app)
    Welcome(app)

    return app
